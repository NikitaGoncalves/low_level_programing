0x00. c - Hello, World
