#include "main.h"

/**
 * add - returns the sum of two numbers
 * @a: int number
 * @b: int number
 *
 * Return: Always 0.
 */
int add(int a, int b)
{
	return (a + b);
}
