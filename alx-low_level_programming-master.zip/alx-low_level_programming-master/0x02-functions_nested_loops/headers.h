#define HEADERS_H_

/*
 * File: headers.h
 * Auth: Franklin Obasi
 * Desc: Header file containing declaration for all functions used
 * 	 in the 0x02-functions_nested_loops directory
 */

int _putchar(char);
