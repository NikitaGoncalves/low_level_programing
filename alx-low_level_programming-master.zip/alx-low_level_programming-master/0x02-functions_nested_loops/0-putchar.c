#include <stdio.h>
#include "main.h"

/**
 * main - Entry Point
 *
 * Return: throws 0 on Success
 */
int main(void)
{
	printf("_putchar\n");
	return (0);
}
