ALX PROJECT
0x11. C - printf
